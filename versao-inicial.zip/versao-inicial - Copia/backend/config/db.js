const config = require('../knexfile.js')
const knex = require('knex')(config)

//Rodar as migrations automaticamente
//knex.migrate.latest([config])

module.exports = knex