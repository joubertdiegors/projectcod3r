<template>
	<div id="app">
		<h1>Versão Inicial</h1>
	</div>
</template>

<script>
export default {
	name: "App",
}
</script>

<style>

</style>